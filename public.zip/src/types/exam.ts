export interface Question {
    question_text: string;
    options: string[];
    correct_answer: number;
    topic: string;
    difficulty: number;
    explanation: string;
  }
  
  export interface ExamResults {
    [x: string]: any;
    score: number;
    topic_analysis: {
      [key: string]: {
        percentage: number;
        correct: number;
        total: number;
        questions: {
          question_text: string;
          correct: boolean;
          explanation: string;
          difficulty: number;
        }[];
      };
    };
    weak_topics: string[];
    strong_topics: string[];
  }

  export type ResourceType = {
    title: string;
    type: 'book' | 'video' | 'practice' | 'online' | 'class';
    description: string;
  };
  
  export type SkillGap = {
    topic: string;
    gap_size: number;
    priority: 'high' | 'medium' | 'low';
    specific_areas: Array<{
      concept: string;
      detailed_explanation: string;
      common_mistakes: string;
      improvement_tips: string;
    }>;
    recommended_resources: ResourceType[];
  };
  