import { NextResponse } from 'next/server';

type Question = {
  topic: string;
  difficulty: number;
  explanation: string;
  question_text: string;
  correct_answer: number;
  options: string[];
};

type QuestionAnalysis = {
  question_text: string;
  correct: boolean;
  explanation: string;
  difficulty: number;
  time_spent?: number;
};

type TopicAnalysis = {
  percentage: number;
  correct: number;
  total: number;
  average_difficulty: number;
  questions: QuestionAnalysis[];
  performance_by_difficulty: {
    easy: { correct: number; total: number };
    medium: { correct: number; total: number };
    hard: { correct: number; total: number };
  };
  recommendations: string[];
};

type ResourceType = {
  title: string;
  type: 'book' | 'video' | 'practice' | 'online' | 'class';
  description: string;
};

type SkillGap = {
  topic: string;
  gap_size: number;
  priority: 'high' | 'medium' | 'low';
  specific_areas: Array<{
    concept: string;
    detailed_explanation: string;
    common_mistakes: string;
    improvement_tips: string;
  }>;
  recommended_resources: ResourceType[];
};

type SpecificArea = {
  concept: string;
  detailed_explanation: string;
  common_mistakes: string;
  improvement_tips: string;
};

const generateDetailedExplanation = (
  topic: string,
  question: Question,
  isCorrect: boolean
): SpecificArea => {
  // Create more detailed explanations based on the topic and question
  const conceptMap: Record<string, SpecificArea> = {
    'کار و انرژی': {
      concept: 'مفهوم کار و انرژی در فیزیک',
      detailed_explanation: `
        در فیزیک، مفهوم کار با زندگی روزمره متفاوت است. نکات کلیدی:
        1. کار برابر است با حاصل‌ضرب نیرو در جابجایی در راستای نیرو
        2. کار می‌تواند مثبت، منفی یا صفر باشد
        3. انرژی جنبشی به جرم و مجذور سرعت وابسته است
        4. انرژی پتانسیل گرانشی به جرم، شتاب گرانش و ارتفاع بستگی دارد
        5. قانون پایستگی انرژی در سیستم‌های بسته همواره برقرار است
        
        در این سوال خاص، ${typeof question.explanation === 'string' ? question.explanation : question.explanation.detailed_explanation}`,
      common_mistakes: `
        اشتباهات رایج در این مبحث:
        1. عدم توجه به جهت نیرو در محاسبه کار
        2. فراموش کردن علامت کار در محاسبات
        3. اشتباه در تشخیص سیستم‌های پایسته و ناپایسته
        4. عدم توجه به تبدیل واحدها در محاسبات
        5. اشتباه در محاسبه تغییرات انرژی پتانسیل و جنبشی`,
      improvement_tips: `
        برای تسلط بیشتر:
        1. مفاهیم پایه را با دقت مطالعه کنید
        2. مثال‌های متنوع حل کنید
        3. نمودارهای انرژی را تحلیل کنید
        4. تمرین‌های ترکیبی با سایر مباحث را حل کنید
        5. از شبیه‌سازی‌های فیزیکی استفاده کنید
        6. مسائل را گام به گام حل کنید
        7. با همکلاسی‌ها مباحث را به بحث بگذارید`
    },
    'نمودار سرعت-زمان': {
      concept: 'تحلیل نمودار سرعت-زمان',
      detailed_explanation: `
        در تحلیل نمودار سرعت-زمان، باید به موارد زیر توجه کرد:
        1. شیب نمودار نشان‌دهنده شتاب است
        2. مساحت زیر نمودار برابر با جابجایی است
        3. نقاط برخورد با محور زمان نشان‌دهنده تغییر جهت حرکت است
        4. خط افقی نشان‌دهنده حرکت با سرعت ثابت است
        5. خط مورب نشان‌دهنده حرکت با شتاب ثابت است
        
        در این سوال خاص، ${typeof question.explanation === 'string' ? question.explanation : question.explanation.detailed_explanation}`,
      common_mistakes: `
        اشتباهات رایج در تحلیل نمودار سرعت-زمان:
        1. اشتباه در تشخیص شتاب مثبت و منفی
        2. اشتباه در محاسبه مساحت زیر نمودار
        3. عدم توجه به علامت سرعت و جهت حرکت
        4. اشتباه در تفسیر نقاط برخورد با محور زمان
        5. خطا در تشخیص نوع حرکت از روی شکل نمودار`,
      improvement_tips: `
        برای تسلط بر تحلیل نمودار:
        1. تمرین مداوم رسم و تحلیل نمودار
        2. تبدیل توصیف حرکت به نمودار و برعکس
        3. محاسبه دقیق مساحت‌ها و شیب‌ها
        4. تمرین سوالات ترکیبی با سایر مباحث
        5. استفاده از نرم‌افزارهای شبیه‌سازی حرکت`
    },
  };

  // Check if the question's explanation is an object with the expected structure
  const explanationObj = typeof question.explanation === 'object' ? question.explanation : null;

  // If we have a predefined concept map for this topic, use it
  if (topic in conceptMap) {
    const baseExplanation = conceptMap[topic];
    return {
      ...baseExplanation,
      detailed_explanation: baseExplanation.detailed_explanation + (
        explanationObj?.detailed_explanation || 
        (typeof question.explanation === 'string' ? question.explanation : '')
      )
    };
  }

  // If we don't have a predefined concept map but have a structured explanation object
  if (explanationObj) {
    return {
      concept: explanationObj.concept || topic,
      detailed_explanation: explanationObj.detailed_explanation || '',
      common_mistakes: explanationObj.common_mistakes || `اشتباهات رایج در ${topic}:
        1. عدم درک صحیح مفاهیم پایه
        2. اشتباه در استفاده از فرمول‌ها
        3. بی‌توجهی به واحدها
        4. عدم تشخیص درست شرایط مسئله`,
      improvement_tips: explanationObj.improvement_tips || `روش‌های بهبود در ${topic}:
        1. مطالعه دقیق کتاب درسی
        2. حل تمرین‌های متنوع
        3. شرکت در کلاس‌های رفع اشکال
        4. استفاده از منابع کمک آموزشی معتبر`
    };
  }

  // Default fallback when we have neither
  return {
    concept: topic,
    detailed_explanation: typeof question.explanation === 'string' 
      ? question.explanation 
      : `توضیح تفصیلی برای ${topic}`,
    common_mistakes: `اشتباهات رایج در ${topic}:
      1. عدم درک صحیح مفاهیم پایه
      2. اشتباه در استفاده از فرمول‌ها
      3. بی‌توجهی به واحدها
      4. عدم تشخیص درست شرایط مسئله`,
    improvement_tips: `روش‌های بهبود در ${topic}:
      1. مطالعه دقیق کتاب درسی
      2. حل تمرین‌های متنوع
      3. شرکت در کلاس‌های رفع اشکال
      4. استفاده از منابع کمک آموزشی معتبر`
  };
};

const getTopicSpecificResources = (topic: string): ResourceType[] => {
  const commonResources: ResourceType[] = [
    {
      title: 'کتاب درسی',
      type: 'book',
      description: 'مطالعه دقیق مفاهیم و حل تمرین‌های کتاب درسی به همراه پاسخ تشریحی'
    },
    {
      title: 'ویدیوهای آموزشی تعاملی',
      type: 'video',
      description: 'آموزش گام به گام مفاهیم با انیمیشن و مثال‌های متنوع'
    },
    {
      title: 'آزمون‌های آنلاین',
      type: 'online',
      description: 'تمرین‌های تعاملی با بازخورد فوری و توضیحات کامل'
    },
    {
      title: 'کلاس‌های رفع اشکال',
      type: 'class',
      description: 'جلسات حل تمرین و رفع اشکال با دبیر'
    }
  ];

  const topicSpecificMap: Record<string, ResourceType[]> = {
    'کار و انرژی': [
      ...commonResources,
      {
        title: 'شبیه‌ساز آنلاین کار و انرژی',
        type: 'practice',
        description: 'تجربه عملی مفاهیم کار و انرژی با شبیه‌ساز تعاملی'
      }
    ],
    // Add other topics with their specific resources
  };

  return topicSpecificMap[topic] || commonResources;
};

const getDifficultyLevel = (difficulty: number) => {
  if (difficulty <= 2) return 'easy';
  if (difficulty <= 3) return 'medium';
  return 'hard';
};

const generateTopicRecommendations = (
  topicData: TopicAnalysis,
  topic: string
): string[] => {
  const recommendations: string[] = [];
  const { percentage, performance_by_difficulty, questions } = topicData;

  // Basic performance analysis
  if (percentage < 60) {
    recommendations.push(
      `برای تقویت مبحث ${topic}، پیشنهاد می‌شود ابتدا مفاهیم پایه را مرور کنید. بهتر است از کتاب درسی شروع کرده و تمرین‌های ساده را حل کنید.`
    );
  }

  // Difficulty-based analysis
  const { easy, medium, hard } = performance_by_difficulty;
  if (easy.correct / easy.total < 0.7) {
    recommendations.push(
      `عملکرد شما در سوالات ساده ${topic} نیاز به بهبود دارد. توصیه می‌شود روی مفاهیم اصلی و پایه‌ای تمرکز کنید و تمرین‌های بیشتری حل کنید.`
    );
  }
  
  if (medium.correct / medium.total < 0.6) {
    recommendations.push(
      `در سوالات با سختی متوسط ${topic}، نیاز به تمرین بیشتر دارید. پیشنهاد می‌شود از تمرین‌های متنوع استفاده کرده و روش‌های حل مسئله را تقویت کنید.`
    );
  }

  if (hard.total > 0 && hard.correct / hard.total < 0.5) {
    recommendations.push(
      `برای تسلط بیشتر بر سوالات پیشرفته ${topic}، پیشنهاد می‌شود مسائل ترکیبی و چالشی را تمرین کنید و ارتباط این مبحث با سایر مباحث را بررسی کنید.`
    );
  }

  // Pattern analysis
  const incorrectPatterns = questions
    .filter(q => !q.correct)
    .reduce((patterns, q) => {
      const diffLevel = getDifficultyLevel(q.difficulty);
      patterns[diffLevel] = (patterns[diffLevel] || 0) + 1;
      return patterns;
    }, {} as Record<string, number>);

  // Add specific recommendations based on patterns
  if (incorrectPatterns.easy > 1) {
    recommendations.push(
      `به نظر می‌رسد در درک مفاهیم پایه ${topic} مشکل دارید. پیشنهاد می‌شود از دبیر خود بخواهید این مفاهیم را مجدداً توضیح دهد.`
    );
  }

  return recommendations;
};

export async function POST(req: Request) {
  try {
    const { answers, questions } = await req.json();
    
    // Calculate overall score
    const total_questions = answers.length;
    const correct_count = answers.reduce((acc: number, curr: number, idx: number) => 
      acc + (curr === questions[idx].correct_answer ? 1 : 0), 0);
    const score = (correct_count / total_questions) * 100;

    // Initialize detailed analysis
    const topic_analysis: Record<string, TopicAnalysis> = {};
    const weak_topics: string[] = [];
    const strong_topics: string[] = [];
    const skill_gaps: SkillGap[] = [];

    // Analyze each question and topic
    questions.forEach((question: Question, idx: number) => {
      const topic = question.topic;
      const is_correct = answers[idx] === question.correct_answer;
      const difficulty_level = getDifficultyLevel(question.difficulty);
      

      if (!topic_analysis[topic]) {
        topic_analysis[topic] = {
          correct: 0,
          total: 0,
          percentage: 0,
          average_difficulty: 0,
          questions: [],
          performance_by_difficulty: {
            easy: { correct: 0, total: 0 },
            medium: { correct: 0, total: 0 },
            hard: { correct: 0, total: 0 }
          },
          recommendations: []
        };
      }

      if (!is_correct) {
        const detailedAnalysis = generateDetailedExplanation(topic, question, is_correct);
        const existingGapIndex = skill_gaps.findIndex(gap => gap.topic === topic);
        
        if (existingGapIndex >= 0) {
          // Add to existing gap
          skill_gaps[existingGapIndex].specific_areas.push(detailedAnalysis);
        } else {
          // Create new gap
          skill_gaps.push({
            topic,
            gap_size: 70 - (topic_analysis[topic].percentage || 0),
            priority: (topic_analysis[topic].percentage || 0) < 50 ? 'high' : 'medium',
            specific_areas: [detailedAnalysis],
            recommended_resources: getTopicSpecificResources(topic)
          });
        }
      }

      // Update topic statistics
      topic_analysis[topic].total += 1;
      topic_analysis[topic].correct += is_correct ? 1 : 0;
      topic_analysis[topic].average_difficulty += question.difficulty;
      
      // Update difficulty-based performance
      topic_analysis[topic].performance_by_difficulty[difficulty_level].total += 1;
      if (is_correct) {
        topic_analysis[topic].performance_by_difficulty[difficulty_level].correct += 1;
      }

      // Add question details
      topic_analysis[topic].questions.push({
        question_text: question.question_text,
        correct: is_correct,
        explanation: question.explanation,
        difficulty: question.difficulty
      });
    });

    // Calculate final statistics and generate recommendations
    Object.entries(topic_analysis).forEach(([topic, data]) => {
      // Calculate percentages
      data.percentage = (data.correct / data.total) * 100;
      data.average_difficulty /= data.total;

      // Generate topic-specific recommendations
      data.recommendations = generateTopicRecommendations(data, topic);

      // Categorize topic performance
      if (data.percentage < 70) {
        weak_topics.push(topic);
        
        // Convert question explanations to proper specific areas
        const questionAnalyses = data.questions
          .filter(q => !q.correct)
          .map(q => {
            const question = questions.find((origQ: { question_text: string; }) => origQ.question_text === q.question_text);
            return question ? generateDetailedExplanation(topic, question, false) : null;
          })
          .filter((analysis): analysis is SpecificArea => analysis !== null);
      
        // Add to skill gaps if we have analyses
        if (questionAnalyses.length > 0) {
          const existingGapIndex = skill_gaps.findIndex(gap => gap.topic === topic);
          
          if (existingGapIndex >= 0) {
            skill_gaps[existingGapIndex].specific_areas.push(...questionAnalyses);
          } else {
            skill_gaps.push({
              topic,
              gap_size: 70 - data.percentage,
              priority: data.percentage < 50 ? 'high' : 'medium',
              specific_areas: questionAnalyses,
              recommended_resources: getTopicSpecificResources(topic)
            });
          }
        }
      }
      else if (data.percentage >= 90) {
        strong_topics.push(topic);
      }
    });

    // Generate overall recommendations
    const overall_recommendations = {
      study_plan: `برای بهبود عملکرد خود، پیشنهاد می‌شود روی ${weak_topics.join('، ')} تمرکز کنید. برای هر مبحث، ابتدا مفاهیم پایه را مرور کرده و سپس به سراغ تمرین‌های پیشرفته‌تر بروید.`,
      next_steps: weak_topics.map(topic => ({
        topic,
        steps: [
          'مرور مفاهیم پایه از کتاب درسی',
          'حل تمرین‌های ساده و متوسط',
          'شرکت در کلاس‌های رفع اشکال',
          'تمرین سوالات پیشرفته'
        ]
      }))
    };

    return NextResponse.json({
      score,
      topic_analysis,
      weak_topics,
      strong_topics,
      skill_gaps,
      overall_recommendations
    });
  } catch (error) {
    console.error('Error evaluating exam:', error);
    return NextResponse.json(
      { error: 'Failed to evaluate exam' },
      { status: 500 }
    );
  }
}