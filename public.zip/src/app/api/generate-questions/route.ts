import { GoogleGenerativeAI } from "@google/generative-ai";
import { NextResponse } from 'next/server';

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');

// Helper to validate the question structure
const isValidQuestion = (question: any): boolean => {
  return (
    question &&
    typeof question.question_text === 'string' &&
    Array.isArray(question.options) &&
    question.options.length === 4 &&
    typeof question.correct_answer === 'number' &&
    typeof question.topic === 'string' &&
    typeof question.difficulty === 'number' &&
    question.explanation &&
    typeof question.explanation.concept === 'string' &&
    typeof question.explanation.detailed_explanation === 'string' &&
    typeof question.explanation.common_mistakes === 'string' &&
    typeof question.explanation.improvement_tips === 'string'
  );
};

// Helper to validate the response structure
const isValidResponse = (data: any): boolean => {
  return (
    data &&
    Array.isArray(data.questions) &&
    data.questions.length > 0 &&
    data.questions.every(isValidQuestion)
  );
};

// Helper to handle JSON parsing with fallback
const safeJSONParse = (text: string) => {
  try {
    const cleanedText = text.replace(/```json\n?|\n?```/g, '').trim();
    return JSON.parse(cleanedText);
  } catch (error) {
    return null;
  }
};

// Function to generate questions with retry logic
const generateQuestionsWithRetry = async (
  lessonContent: string,
  maxRetries: number = 3
): Promise<any> => {
  const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });
  
  const prompt = `به عنوان یک دبیر فیزیک با تجربه، ۱۰ سوال چهارگزینه‌ای برای مبحث "${lessonContent}" طراحی کنید.

هر سوال باید شامل موارد زیر باشد:
1. متن سوال باید دقیق، علمی و کاملاً واضح باشد
2. چهار گزینه که:
   - هر گزینه منطقی و مرتبط با سوال باشد
   - گزینه‌های نادرست باید بر اساس اشتباهات رایج دانش‌آموزان طراحی شوند
   - گزینه‌ها باید از نظر طول و ساختار متوازن باشند
3. درجه سختی از ۱ تا ۵:
   - ۱-۲: سوالات پایه و مفهومی
   - ۳: سوالات متوسط
   - ۴-۵: سوالات چالشی و ترکیبی
4. توضیح کامل پاسخ که شامل:
   - مفهوم کلیدی که سوال می‌سنجد
   - روش حل گام به گام
   - دلیل نادرست بودن سایر گزینه‌ها
   - نکات مهم و دام‌های تستی
   - اشتباهات رایج در این نوع سوال
   - روش‌های تسلط بر این مبحث

لطفا پاسخ را به صورت آرایه JSON با ساختار زیر برگردانید (بدون markdown یا code block):
{
  "questions": [
    {
      "question_text": "متن سوال",
      "options": ["گزینه ۱", "گزینه ۲", "گزینه ۳", "گزینه ۴"],
      "correct_answer": 0,
      "topic": "مبحث دقیق سوال",
      "difficulty": 3,
      "explanation": {
        "concept": "مفهوم کلیدی",
        "detailed_explanation": "توضیح کامل با ذکر فرمول‌ها و روش حل",
        "common_mistakes": "اشتباهات رایج دانش‌آموزان",
        "improvement_tips": "روش‌های تسلط بر مبحث"
      }
    }
  ]
}

پاسخ باید حتما به صورت JSON معتبر باشد.`;

  let lastError = null;
  
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      const result = await model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      const parsedData = safeJSONParse(text);
      
      if (parsedData && isValidResponse(parsedData)) {
        return parsedData;
      }
      
      // If we get here, the response wasn't valid, but didn't throw an error
      // We'll throw our own error to trigger a retry
      throw new Error('Invalid response format');
      
    } catch (error) {
      lastError = error;
      console.error(`Attempt ${attempt + 1} failed:`, error);
      
      // On last attempt, prepare fallback questions
      if (attempt === maxRetries - 1) {
        return {
          questions: [
            {
              question_text: `جسمی به جرم ۲ کیلوگرم با سرعت اولیه ۵ متر بر ثانیه روی سطح افقی بدون اصطکاک حرکت می‌کند. اگر نیروی ثابت ۴ نیوتن در جهت حرکت به آن وارد شود، پس از ۲ ثانیه سرعت جسم چند متر بر ثانیه خواهد بود؟`,
              options: ["۹", "۱۴", "۱۱", "۷"],
              correct_answer: 0,
              topic: "دینامیک و قوانین نیوتن",
              difficulty: 2,
              explanation: {
                concept: "قانون دوم نیوتن (F=ma)",
                detailed_explanation: "شتاب: a = F/m = 4/2 = 2 m/s^2. تغییر سرعت: Δv = at = 2*2 = 4 m/s. سرعت نهایی: v = v0 + Δv = 5 + 4 = 9 m/s",
                common_mistakes: "فراموش کردن سرعت اولیه در محاسبه سرعت نهایی",
                improvement_tips: "تمرین سوالات مشابه و توجه به واحدها"
              }
            }
            // Add more fallback questions as needed
          ]
        };
      }
      
      // Wait a short time before retrying
      await new Promise(resolve => setTimeout(resolve, 1000 * (attempt + 1)));
    }
  }
  
  throw lastError;
};

export async function POST(req: Request) {
  try {
    const { lessonContent } = await req.json();
    const questions = await generateQuestionsWithRetry(lessonContent);
    return NextResponse.json(questions);
  } catch (error) {
    console.error('Error in question generation:', error);
    // Return fallback questions instead of an error
    return NextResponse.json({
      questions: [
        {
          question_text: `جسمی به جرم ۲ کیلوگرم با سرعت اولیه ۵ متر بر ثانیه روی سطح افقی بدون اصطکاک حرکت می‌کند. اگر نیروی ثابت ۴ نیوتن در جهت حرکت به آن وارد شود، پس از ۲ ثانیه سرعت جسم چند متر بر ثانیه خواهد بود؟`,
          options: ["۹", "۱۴", "۱۱", "۷"],
          correct_answer: 0,
          topic: "دینامیک و قوانین نیوتن",
          difficulty: 2,
          explanation: {
            concept: "قانون دوم نیوتن (F=ma)",
            detailed_explanation: "شتاب: a = F/m = 4/2 = 2 m/s^2. تغییر سرعت: Δv = at = 2*2 = 4 m/s. سرعت نهایی: v = v0 + Δv = 5 + 4 = 9 m/s",
            common_mistakes: "فراموش کردن سرعت اولیه در محاسبه سرعت نهایی",
            improvement_tips: "تمرین سوالات مشابه و توجه به واحدها"
          }
        }
        // Add more fallback questions as needed
      ]
    });
  }
}