'use client';
import React, { useState } from 'react';
import { AlertCircle, BookOpen, CheckCircle, Globe, Target, Users, Video } from 'lucide-react';
import { Question, ExamResults, SkillGap, ResourceType } from '@/types/exam';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';

type ExamState = 'start' | 'questions' | 'results';

// Add type validation helper
const isValidQuestionData = (data: any): data is { questions: Question[] } => {
  return (
    data &&
    Array.isArray(data.questions) &&
    data.questions.every((q: any) =>
      q.question_text &&
      Array.isArray(q.options) &&
      typeof q.correct_answer === 'number' &&
      typeof q.difficulty === 'number' &&
      q.topic &&
      q.explanation
    )
  );
};

const ExamInterface = () => {
  const [examState, setExamState] = useState<ExamState>('start');
  const [currentQuestion, setCurrentQuestion] = useState<number>(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [examData, setExamData] = useState<Question[] | null>(null);
  const [results, setResults] = useState<ExamResults | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const lessonContent = `فصل سوم فیزیک دهم`;

  const startExam = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/generate-questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lessonContent }),
      });
      const data = await response.json();
      
      // Validate the response data
      if (isValidQuestionData(data)) {
        setExamData(data.questions);
        setExamState('questions');
      } else {
        console.error('Invalid question data format:', data);
        setError('دریافت سؤالات با مشکل مواجه شد. لطفاً دوباره تلاش کنید.');
      }
    } catch (error) {
      console.error('Failed to generate questions:', error);
      setError('خطا در دریافت سؤالات. لطفاً دوباره تلاش کنید.');
    }
    setLoading(false);
  };


  const handleAnswer = (answerIndex: number) => {
    if (!examData) return;
    
    const newAnswers = [...answers, answerIndex];
    setAnswers(newAnswers);

    if (newAnswers.length === examData.length) {
      submitExam(newAnswers);
    } else {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const submitExam = async (finalAnswers: number[]) => {
    if (!examData) return;
    
    setLoading(true);
    try {
      const response = await fetch('/api/evaluate-exam', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          answers: finalAnswers,
          questions: examData,
        }),
      });
      const results = await response.json();
      setResults(results);
      setExamState('results');
    } catch (error) {
      console.error('Failed to evaluate exam:', error);
    }
    setLoading(false);
  };

  const renderStartScreen = () => (
    <Card className="max-w-2xl mx-auto mt-8">
      <CardHeader>
        <CardTitle className="text-2xl font-bold text-center">
        
        </CardTitle>
      </CardHeader>
      <CardContent className="text-center">
        <p className="mb-6 text-gray-700 font-semibold">
        سپهر عزیز ، معلم فیزیکت ، اقای مهندس طباطبایی گفته که فصل سوم را کامل درس داده و مطمئن بود تو به عنوان یکی از دانش آموزای خوب کلاس درس رو یاد گرفتی .
        اگر اماده ای با هم به چند سوال مرتبط جواب بدیم تا من و اقای مهندس طباطیایی خیالمون راحت باشه که همه چیز رواله
        </p>
        {error && (
          <div className="mb-4 p-4 bg-red-50 text-red-600 rounded-lg flex items-center">
            <AlertCircle className="w-5 h-5 ml-2" />
            {error}
          </div>
        )}
        <Button 
          onClick={startExam} 
          disabled={loading}
          className="w-full max-w-xs"
        >
          {loading ? 'در حال آماده سازی...' : 'بزن بریم'}
        </Button>
      </CardContent>
    </Card>
  );
  const renderQuestion = () => {
    if (!examData || !examData[currentQuestion]) return null;
    
    const question = examData[currentQuestion];
    return (
      <Card className="max-w-2xl mx-auto mt-8">
        <CardHeader>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-500">
              سوال {currentQuestion + 1} از {examData.length}
            </span>
            <span className="text-sm text-gray-500">
              درجه سختی: {question.difficulty}/5
            </span>
          </div>
          <CardTitle className="text-xl mt-4">{question.question_text}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {question.options.map((option, index) => (
              <Button
                key={index}
                onClick={() => handleAnswer(index)}
                className="w-full text-right"
                variant="outline"
              >
                {option}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  };

  const renderResults = () => {
    if (!results) return null;
  
    return (
      <Card className="max-w-4xl mx-auto mt-8">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">
            نتایج و تحلیل عملکرد
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Overall Score */}
          <div className="mb-8 text-center">
            <div className="text-3xl font-bold mb-2">
              نمره کل: {results.score.toFixed(1)}%
            </div>
            <Progress value={results.score} className="w-full max-w-md mx-auto" />
          </div>
  
          {/* Strong Topics */}
          <div className="mb-8">
            <h3 className="font-bold mb-4 flex items-center text-xl">
              <CheckCircle className="w-6 h-6 text-green-500 ml-2" />
              نقاط قوت
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {results.strong_topics.map((topic) => (
                <Card key={topic} className="p-4 bg-green-50">
                  <div className="font-semibold text-green-700">{topic}</div>
                  <div className="text-sm text-green-600 mt-2">
                    تسلط: {results.topic_analysis[topic].percentage.toFixed(1)}%
                  </div>
                </Card>
              ))}
            </div>
          </div>
  
          {/* Areas for Improvement */}
          <div className="mb-8">
        <h3 className="font-bold mb-4 flex items-center text-xl">
          <Target className="w-6 h-6 text-red-500 ml-2" />
          مباحث نیازمند تقویت
        </h3>
        {results.skill_gaps.map((gap: SkillGap) => (
          <Card key={gap.topic} className="mb-4 p-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold text-lg">{gap.topic}</h4>
              <span className={`px-3 py-1 rounded-full text-sm ${
                gap.priority === 'high' ? 'bg-red-100 text-red-700' :
                gap.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                'bg-blue-100 text-blue-700'
              }`}>
                {gap.priority === 'high' ? 'اولویت بالا' :
                 gap.priority === 'medium' ? 'اولویت متوسط' :
                 'اولویت پایین'}
              </span>
            </div>
            
            {gap.specific_areas.map((area, idx) => (
              <div key={idx} className="mb-6 bg-gray-50 p-4 rounded-lg">
                <h5 className="font-semibold mb-2">مفهوم کلیدی:</h5>
                <p className="text-gray-700 mb-4">{area.concept}</p>
                
                <h5 className="font-semibold mb-2">توضیح تکمیلی:</h5>
                <p className="text-gray-700 mb-4">{area.detailed_explanation}</p>
                
                <h5 className="font-semibold mb-2">اشتباهات رایج:</h5>
                <p className="text-gray-700 mb-4">{area.common_mistakes}</p>
                
                <h5 className="font-semibold mb-2">راهکارهای بهبود:</h5>
                <p className="text-gray-700 whitespace-pre-line">{area.improvement_tips}</p>
              </div>
            ))}

            <div className="mt-6">
              <h5 className="font-semibold mb-3">منابع پیشنهادی:</h5>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {gap.recommended_resources.map((resource: ResourceType, idx) => (
                  <div key={idx} className="bg-white p-4 rounded-lg border">
                    <div className="flex items-center gap-2 mb-2">
                      {resource.type === 'book' && <BookOpen className="w-4 h-4" />}
                      {resource.type === 'video' && <Video className="w-4 h-4" />}
                      {resource.type === 'online' && <Globe className="w-4 h-4" />}
                      {resource.type === 'class' && <Users className="w-4 h-4" />}
                      <span className="font-semibold">{resource.title}</span>
                    </div>
                    <p className="text-sm text-gray-600">{resource.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        ))}
      </div>
  
          {/* Study Plan */}
          <div className="mb-8">
            <h3 className="font-bold mb-4 flex items-center text-xl">
              <BookOpen className="w-6 h-6 text-blue-500 ml-2" />
              برنامه مطالعاتی پیشنهادی
            </h3>
            <Card className="p-6">
              <p className="text-gray-700 mb-6">{results.overall_recommendations.study_plan}</p>
              
              <div className="space-y-6">
                {results.overall_recommendations.next_steps.map((step) => (
                  <div key={step.topic} className="border-r-4 border-blue-500 pr-4">
                    <h4 className="font-semibold mb-2">{step.topic}</h4>
                    <ol className="list-decimal list-inside space-y-2">
                      {step.steps.map((s, idx) => (
                        <li key={idx} className="text-gray-600">{s}</li>
                      ))}
                    </ol>
                  </div>
                ))}
              </div>
            </Card>
          </div>
  
          <Button 
            onClick={() => {
              setExamState('start');
              setAnswers([]);
              setCurrentQuestion(0);
              setExamData(null);
              setResults(null);
            }}
            className="w-full mt-8"
          >
            شروع مجدد آزمون
          </Button>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="container mx-auto px-4 py-8 rtl">
      {examState === 'start' && renderStartScreen()}
      {examState === 'questions' && examData && renderQuestion()}
      {examState === 'results' && results && renderResults()}
    </div>
  );
};

export default ExamInterface;